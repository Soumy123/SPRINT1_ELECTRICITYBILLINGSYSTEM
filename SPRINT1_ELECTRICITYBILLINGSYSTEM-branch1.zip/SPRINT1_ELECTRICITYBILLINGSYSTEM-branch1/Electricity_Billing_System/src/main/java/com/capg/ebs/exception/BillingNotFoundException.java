package com.capg.ebs.exception;
@SuppressWarnings("serial")
public class BillingNotFoundException extends RuntimeException {
		
}
