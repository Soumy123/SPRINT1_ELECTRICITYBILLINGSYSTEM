package com.capg.ebs.dto;

import org.springframework.stereotype.Component;

@Component
public class CustomerDto {
	

}
