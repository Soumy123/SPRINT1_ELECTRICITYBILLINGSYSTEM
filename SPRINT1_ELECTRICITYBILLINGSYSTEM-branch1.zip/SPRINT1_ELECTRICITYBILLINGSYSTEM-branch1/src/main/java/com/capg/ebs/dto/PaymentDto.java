package com.capg.ebs.dto;

public class PaymentDto {
	

}
