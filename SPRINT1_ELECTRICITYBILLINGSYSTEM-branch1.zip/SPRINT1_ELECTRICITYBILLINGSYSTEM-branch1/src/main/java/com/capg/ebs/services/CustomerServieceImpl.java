package com.capg.ebs.services;

import java.util.List;

import com.capg.ebs.entities.Customer;

public class CustomerServieceImpl implements ICustomerServiece {

	@Override
	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customer;
	}

	@Override
	public Customer updateCustomer(Customer cust) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer getCustomerById(int cid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteCustomerById(int cid) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

}
