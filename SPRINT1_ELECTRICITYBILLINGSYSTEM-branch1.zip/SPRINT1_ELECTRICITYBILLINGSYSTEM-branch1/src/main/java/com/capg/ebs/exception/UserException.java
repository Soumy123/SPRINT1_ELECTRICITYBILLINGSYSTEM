package com.capg.ebs.exception;

public class UserException {

}
