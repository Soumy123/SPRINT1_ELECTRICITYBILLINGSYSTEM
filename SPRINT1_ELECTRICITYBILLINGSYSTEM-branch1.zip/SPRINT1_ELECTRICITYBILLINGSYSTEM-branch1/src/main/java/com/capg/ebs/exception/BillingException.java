package com.capg.ebs.exception;

public class BillingException {

}
